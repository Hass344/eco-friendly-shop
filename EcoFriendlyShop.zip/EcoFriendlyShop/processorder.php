<?php
// Simulating a POST request for testing
$_POST['product'] = 'Reusable Bags';
$_POST['quantity'] = 2;

// Check if the POST data is set
if (isset($_POST['product']) && isset($_POST['quantity'])) {
    $product = $_POST['product'];
    $quantity = $_POST['quantity'];

    // Process the order
    echo "Order received for " . htmlspecialchars($quantity) . " " . htmlspecialchars($product) . "(s).";
} else {
    echo "No order submitted.";
}
?>
